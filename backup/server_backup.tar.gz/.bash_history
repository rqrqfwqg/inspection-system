 
sudo apt update && sudo apt upgrade -y
cd /root/inspection-system/backend
# 创建一个补丁脚本
cat > add_api_patch.py << 'EOF'
import re

with open('main.py', 'r', encoding='utf-8') as f:
    content = f.read()

# 检查是否已有接口
if '/api/inspection-plans/list' in content:
    print("接口已存在，无需添加")
    exit(0)

# 找到合适的位置插入（在 get_inspection_plans 函数之后）
# 搜索模式：找到最后一个 @app.get 装饰的函数结束位置

# 在 /api/inspection-plans/current 接口之后插入
new_code = '''

@app.get("/api/inspection-plans/list", response_model=dict)
def get_inspection_plan_list(
    year: int,
    month: int,
    db: Session = Depends(get_db)
):
    """获取巡查计划列表（概要）- 懒加载用"""
    plan = db.query(InspectionPlan).filter(
        InspectionPlan.year == year,
        InspectionPlan.month == month
    ).order_by(InspectionPlan.created_at.desc()).first()

    if not plan:
        return {"year": year, "month": month, "days": []}

    plan_data = json.loads(plan.data) if plan.data else {}
    
    days_list = []
    for date_str, day_data in plan_data.items():
        days_list.append({
            "date": date_str,
            "day": day_data.get("day"),
            "high": day_data.get("high", 0),
            "low": day_data.get("low", 0),
            "total": day_data.get("total", 0),
            "floors": day_data.get("floors", []),
        })
    
    days_list.sort(key=lambda x: x["date"])
    
    return {
        "year": year,
        "month": month,
        "plan_id": plan.id,
        "days": days_list
    }


@app.get("/api/inspection-plans/{plan_id}/day/{date}", response_model=dict)
def get_inspection_plan_day_detail(
    plan_id: int,
    date: str,
    db: Session = Depends(get_db)
):
    """获取某天巡查计划详情"""
    plan = db.query(InspectionPlan).filter(InspectionPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="计划不存在")
    
    plan_data = json.loads(plan.data) if plan.data else {}
    day_data = plan_data.get(date)
    
    if not day_data:
        raise HTTPException(status_code=404, detail="日期不存在")
    
    return {
        "date": date,
        "day": day_data.get("day"),
        "high": day_data.get("high", 0),
        "low": day_data.get("low", 0),
        "total": day_data.get("total", 0),
        "floors": day_data.get("floors", []),
        "morning": day_data.get("morning"),
        "evening": day_data.get("evening"),
    }

'''

# 找到 "by-year-month" 接口后的位置插入
pattern = r'(@app\.get\("/api/inspection-plans/by-year-month".*?return \{[^}]+\}\n)'
match = re.search(pattern, content, re.DOTALL)
if match:
    insert_pos = match.end()
    content = content[:insert_pos] + new_code + content[insert_pos:]
    with open('main.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print("接口添加成功！")
else:
    print("未找到插入位置，请手动添加")
EOF

python3 add_api_patch.py
pkill -f "uvicorn main:app"
sleep 2
nohup python -m uvicorn main:app --host 0.0.0.0 --port 9527 > nohup.out 2>&1 &
sleep 3
curl http://127.0.0.1:9527/api/inspection-plans/list?year=2026&month=3
clear
if ($env:TERM_PROGRAM -eq "vscode") { $Global:__TraeInjectAgain=1; try { . "c:\Users\yan\AppData\Local\Programs\Trae CN\resources\app\out\vs\workbench\contrib\terminal\common\scripts\shellIntegration.ps1" } catch{} }; Write-Output "[Trae CN] Shell integration is not enabled, try to fix it now."
clear
trae-sandbox 'ls -la'
clear
if ($env:TERM_PROGRAM -eq "vscode") { $Global:__TraeInjectAgain=1; try { . "c:\Users\yan\AppData\Local\Programs\Trae CN\resources\app\out\vs\workbench\contrib\terminal\common\scripts\shellIntegration.ps1" } catch{} }; Write-Output "[Trae CN] Shell integration is not enabled, try to fix it now."
clear
trae-sandbox 'ls -la'
clear
if ($env:TERM_PROGRAM -eq "vscode") { $Global:__TraeInjectAgain=1; try { . "c:\Users\yan\AppData\Local\Programs\Trae CN\resources\app\out\vs\workbench\contrib\terminal\common\scripts\shellIntegration.ps1" } catch{} }; Write-Output "[Trae CN] Shell integration is not enabled, try to fix it now."
clear
trae-sandbox 'ls -la'
clear
if ($env:TERM_PROGRAM -eq "vscode") { $Global:__TraeInjectAgain=1; try { . "c:\Users\yan\AppData\Local\Programs\Trae CN\resources\app\out\vs\workbench\contrib\terminal\common\scripts\shellIntegration.ps1" } catch{} }; Write-Output "[Trae CN] Shell integration is not enabled, try to fix it now."
clear
trae-sandbox 'ls -la'
clear
if ($env:TERM_PROGRAM -eq "vscode") { $Global:__TraeInjectAgain=1; try { . "c:\Users\yan\AppData\Local\Programs\Trae CN\resources\app\out\vs\workbench\contrib\terminal\common\scripts\shellIntegration.ps1" } catch{} }; Write-Output "[Trae CN] Shell integration is not enabled, try to fix it now."
clear
trae-sandbox 'ls'
clear
if ($env:TERM_PROGRAM -eq "vscode") { $Global:__TraeInjectAgain=1; try { . "c:\Users\yan\AppData\Local\Programs\Trae CN\resources\app\out\vs\workbench\contrib\terminal\common\scripts\shellIntegration.ps1" } catch{} }; Write-Output "[Trae CN] Shell integration is not enabled, try to fix it now."
clear
trae-sandbox 'tar -czf backup.tar.gz ~/'
